<?php
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'ro_db';

	$conn = mysqli_connect($host,$username,$password,$database);

	// if($conn){
	// 	echo 'Connected successfully!<br>';
	// }

	?>