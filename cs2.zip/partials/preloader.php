<div class="preloader">
	<div class="preloader-container">
		<h1 class="center-align">Now Loading...</h1>
		 <div class="progress">
	      <div class="indeterminate"></div>
	  	</div>
	 </div>
</div>