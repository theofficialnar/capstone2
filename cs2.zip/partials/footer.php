<footer class="page-footer">
	<div class="container">
		<div class="row center-align">
			<span>myRagnarok db Copyright &copy; 2017</span><br>
			<span class="credits">All images and content belong to their respective creators. This website is solely made for educational and fan content purposes. If you have any problems with your media being included in the website, hit me up on narc.ph@gmail.com.</span>
		</div>
	</div>
</footer>