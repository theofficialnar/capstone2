<footer class="page-footer">
	<div class="container">
		<div class="row center-align">
			<span>myRagnarok db Copyright &copy; 2017</span><br>
			<span class="credits">All images and content belong to their respective creators.</span>
		</div>
	</div>
</footer>