<header class="container">
	<h1 class="center-align header-padding"><?php header_title()?></h1>
</header>